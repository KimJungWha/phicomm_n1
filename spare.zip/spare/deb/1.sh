#!/bin/bash

PASSWORD="123"

ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
DEBIAN_FRONTEND=noninteractive dpkg --configure -a

cat > /etc/apt/sources.list <<-EOF
	deb [arch=arm64] https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main contrib non-free
	deb [arch=arm64] https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main contrib non-free
	deb [arch=arm64] https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-backports main contrib non-free
	deb [arch=arm64] https://mirrors.tuna.tsinghua.edu.cn/debian-security bullseye-security main contrib non-free
	
	# deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main contrib non-free
	# deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main contrib non-free
	# deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-backports main contrib non-free
	# deb-src https://mirrors.tuna.tsinghua.edu.cn/debian-security bullseye-security main contrib non-free
EOF

cat > /root/.vimrc <<-EOF
	set fileencodings=utf-8,ucs-bom,gb18030,gbk,gb2312,cp936
	set termencoding=utf-8
	set encoding=utf-8
EOF

echo 'Phicomm-N1' > /etc/hostname
echo -e '127.0.0.1\tPhicomm-N1' >> /etc/hosts
echo 'PermitRootLogin yes' >> /etc/ssh/sshd_config
sed -i '/^#.*%sudo/s/^# //g' /etc/sudoers
echo "root:$PASSWORD" | chpasswd

systemctl enable sshd
systemctl enable networking

dpkg -i /*.deb
rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*
apt clean
