#!/bin/bash
set -aux

sourcedir="/root/linux-5.16.9"
cd $sourcedir
workdir="/root/deb"
rm -rf $workdir
version="$(make -s kernelrelease)"
MAKEFLAGS="-j`echo "$(nproc)*2" | bc`"
toolchain="ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-"

pkg_image() {
	local pkg_name="linux-image-$version-phicomm-n1"
	local output="$workdir/$pkg_name"

	if [ ! -d $output/DEBIAN ];then mkdir -p $output/DEBIAN;fi

	unset LDFLAGS
	#make clean
	#make $toolchain olddefconfig
	#make prepare
	#make -s kernelrelease > version

	# build image
	make $toolchain ${MAKEFLAGS} Image modules

	# build dtb
	make $toolchain ${MAKEFLAGS} DTC_FLAGS="-@" dtbs

	# install boot image
	install -Dm644 arch/arm64/boot/Image $output/boot/zImage

	# install dtbs
	# make $toolchain INSTALL_DTBS_PATH="$output/boot/dtbs" dtbs_install
	install -Dm644 arch/arm64/boot/dts/amlogic/meson-gxl-s905d-phicomm-n1.dtb $output/boot/dtb.img

	# install modules
	make $toolchain INSTALL_MOD_PATH="$output" INSTALL_MOD_STRIP=1 modules_install

	# install same files
	install -Dm644 System.map $output/boot/System.map-$version
	install -Dm644 .config $output/boot/config-$version
	
	# remove useless links
	rm $output/lib/modules/$version/{"source","build"}

	cat > $output/DEBIAN/control <<-EOF
		Package: $pkg_name
		Source: linux-upstream
		Version: $version
		Architecture: arm64
		Maintainer: KimJungWha <beyondjqrz@foxmail.com>
		Section: kernel
		Priority: optional
		Homepage: https://www.kernel.org/
		Description: Linux kernel, version $version for Phicomm N1 (arm64)
		 This package contains the Linux kernel, modules and corresponding other
		 files, version: ${version}.
	EOF

	cat > $output/DEBIAN/postinst <<-EOF
		#!/bin/bash

        if [ ! -f "/boot/initrd.img-$version" ];then
            echo "Create initrd.img..."
            update-initramfs -c -k $version
        else
            echo "Update initrd.img..."
            update-initramfs -u -k $version
        fi

        echo "Generate uInitrd..."
        mkimage -A arm64 -O linux -T ramdisk -C gzip -n uInitrd -d /boot/initrd.img-$version /boot/uInitrd
	EOF

	cat > $output/DEBIAN/postrm <<-EOF
		#!/bin/bash

		echo "Remove Kernel files..."
		rm -rf /boot/*-$version 

		echo "Depmod Modules..."
		/sbin/depmod $version
	EOF

    chmod 0775 $output/DEBIAN/*

	dpkg -b $output $workdir/$pkg_name.deb
}

pkg_headers() {

	local pkg_name="linux-headers-$version-phicomm-n1"
	local output="$workdir/$pkg_name"

	if [ ! -d $output/usr/src/linux-headers-$version ];then mkdir -p $output/usr/src/linux-headers-$version;fi

	(
		find . arch/arm64 -maxdepth 1 -name Makefile\*
		find include scripts -type f -o -type l
		find arch/arm64 -name Kbuild.platforms -o -name Platform
		find $(find arch/arm64 -name include -o -name scripts -type d) -type f
	) > $output/hdrsrcfiles

	(
		find arch/arm64/include Module.symvers include scripts -type f	
	) > $output/hdrobjfiles

	tar -cvf - -C $sourcedir -T $output/hdrsrcfiles | tar -xvf - -C $output/usr/src/linux-headers-$version
	tar -cvf - -T $output/hdrsrcfiles | tar -xvf - -C $output/usr/src/linux-headers-$version
	rm -rf $output/{hdrsrcfiles,hdrobjfiles}

	cp $sourcedir/.config $output/.config
	mkdir -p $output/lib/modules/$version/
	ln -sf /usr/src/linux-headers-$version $output/lib/modules/$version/build
	ln -sf /usr/src/linux-headers-$version $output/lib/modules/$version/source

	mkdir $output/DEBIAN
	cat > $output/DEBIAN/control <<-EOF
		Package: $pkg_name
		Source: linux-upstream
		Version: $version
		Architecture: arm64
		Maintainer: KimJungWha <beyondjqrz@foxmail.com>
		Section: kernel
		Priority: optional
		Homepage: https://www.kernel.org/
		Description: Linux kernel headers for $version on Phicomm N1 (arm64)
		  This package provides kernel header files for $version on Phicomm N1.
		  This is useful for people who need to build external modules
	EOF

	cat > $output/DEBIAN/postrm <<-EOF
		#!/bin/bash
		rm -rf /usr/src/linux-headers-$version 
		rm -rf /lib/modules/$version/{source,build}
	EOF

	chmod 0775 $output/DEBIAN/*

	dpkg -b $output $workdir/$pkg_name.deb
}

pkg_libc() {

	local pkg_name="linux-libc-dev-$version-phicomm-n1"
	local output="$workdir/$pkg_name"

	make $toolchain -f $sourcedir/Makefile headers
	make $toolchain -f $sourcedir/Makefile headers_install INSTALL_HDR_PATH=$output/usr

	mv $output/usr/include/asm $output/usr/include/aarch64-linux-gnu

	mkdir $output/DEBIAN
	cat > $output/DEBIAN/control <<-EOF
		Package: $pkg_name
		Source: linux-upstream
		Version: $version
		Architecture: arm64
		Maintainer: KimJungWha <beyondjqrz@foxmail.com>
		Provides: linux-kernel-headers 
		Section: devel
		Priority: optional
		Multi-Arch: same
		Homepage: https://www.kernel.org/
		Description: Linux support headers for userspace development on Phicomm N1
		 This package provides userspaces headers from the Linux kernel.  These headers
		 are used by the installed headers for GNU glibc and other system libraries.
	EOF

	#cat > $output/DEBIAN/postrm <<-EOF
	#	rm -rf /usr/include/
	#EOF
	#chmod 0775 $output/DEBIAN/*

	dpkg -b $output $workdir/$pkg_name.deb
}

pkg_firmware() {
	local pkg_name="firmware-phicomm-n1"
	local output="$workdir/$pkg_name"

	cd /root/firmware
	install -d "$output/lib/firmware/brcm"
	install -m 0644 *.bin *.hcd *.txt *.clm_blob "$output/lib/firmware/brcm"
	install -m 0644 brcmfmac43455-sdio.txt "$output/lib/firmware/brcm/brcmfmac43455-sdio.phicomm,n1.txt"

	mkdir $output/DEBIAN
	cat > $output/DEBIAN/control <<-EOF
		Package: $pkg_name
		Source: firmware-nonfree
		Version: $version
		Architecture: arm64
		Maintainer: KimJungWha <beyondjqrz@foxmail.com>
		Suggests: initramfs-tools
		Section: non-free/kernel
		Priority: optional
		Multi-Arch: foreign
		Homepage: https://github.com/RPi-Distro/firmware-nonfree.git
		Description: Binary firmware for Broadcom/CYW43455 802.11 wireless cards on Phicomm N1 (same as Raspberry Pi 3B+)
	EOF

	dpkg -b $output $workdir/$pkg_name.deb
}

pkg_image
pkg_headers
pkg_libc
pkg_firmware
