#!/bin/bash
set -aux

IMG="rootfs.img"
DIR="/mnt"

which parted || apt install -qqyf parted
which mkfs.vfat || apt install -y qqyf dosfstools

gen_img () {
	fallocate -l 2G $IMG
	parted -s -a optimal $IMG mklabel msdos mkpart primary fat32 0% 256MiB mkpart primary ext4 256MiB 100%

	LOOP=$(losetup -f -P --show $IMG)
	mkfs.vfat -F 32 -n ARCHBOOT "${LOOP}p1"
	mkfs.ext4 -L ARCHROOT "${LOOP}p2"

	mount "${LOOP}p2" $DIR
	mkdir $DIR/boot
	mount "${LOOP}p1" $DIR/boot
}

gen_rootfs() {
	docker run --rm --privileged multiarch/qemu-user-static --reset --persistent yes --credential yes
	docker run -i --rm --privileged -v $PWD/file:/file -v $DIR:/mnt agners/archlinuxarm-arm64v8 /bin/bash <<-EOF
		/bin/bash /file/2.sh
	EOF
}

gen_bootfs() {
	ROOT_UUID=$(lsblk -n -o UUID "${LOOP}p2")
	BOOT_UUID=$(lsblk -n -o UUID "${LOOP}p1")

	sed -i "s/root_uuid/${ROOT_UUID}/" $DIR/boot/extlinux/extlinux.conf
	echo "UUID=${ROOT_UUID} / ext4 rw,relatime 0 1" > $DIR/etc/fstab
	echo "UUID=${BOOT_UUID} /boot vfat rw,relatime,fmask=0022,dmask=0022,codepage=437,iocharset=ascii,shortname=mixed,utf8,errors=remount-ro 0 2" >> $DIR/etc/fstab

}

end() {
	umount -R $DIR
	losetup -D $LOOP
}

gen_img
gen_rootfs
gen_bootfs
end
