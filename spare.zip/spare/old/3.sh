version=`curl -s https://www.kernel.org | grep -2 "latest_link" | grep href | awk -F '[>,<]' '{print $3}'`
pkgver=`cat PKGBUILD | grep pkgver= | awk -F '=' '{print $2}'`
sed -i "s/$pkgver/$version/" PKGBUILD
