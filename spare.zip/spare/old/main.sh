#!/bin/bash
set -aux

DIR="/rootfs"

env_init() {
	echo 'Server = https://mirrors.tuna.tsinghua.edu.cn/archlinuxarm/$arch/$repo' > /etc/pacman.d/mirrorlist
	pacman -Sy arch-install-scripts --noconfirm
}

gen_rootfs() {
	pacstrap $DIR base base-devel vim parted openssh uboot-tools rsync

	echo -e "en_US.UTF-8 UTF-8\n en_GB.UTF-8 UTF-8" >> $DIR/etc/locale.gen
	echo 'Phicomm-N1' > $DIR/etc/hostname
	echo -e '127.0.0.1\tPhicomm-N1' >> $DIR/etc/hosts

	cat > $DIR/etc/systemd/network/eth.network <<-EOF
		[Match]
		Name=eth0

		[Network]
		DHCP=ipv4

		# Static 
		# Address=192.168.2.253/24
		# Gateway=192.168.2.254

		[Link]
		# Set to yes to disable this network
		Unmanaged=no
	EOF

	cp -rf /file/uboot/* $DIR/boot
	cp -rf /file/linux* $DIR/
	cp -rf /file/install.sh $DIR/root/

	#mount -t proc /proc $DIR/proc
	#for i in {sys,dev,run};do
	#	mount --make-rslave --rbind /$i $DIR/$i
	#done

	mount --bind $DIR $DIR
	arch-chroot $DIR /bin/bash <<-EOF
		locale-gen
		localectl set-locale LANG=en_US.UTF-8 LC_TIME=en_GB.UTF-8

		echo 'root:123' | chpasswd

		pacman-key --init
		pacman-key --populate archlinuxarm

		systemctl enable sshd
		systemctl enable systemd-networkd

		pacman -U /linux-phicomm-n1* --noconfirm
		pacman -Sc --noconfirm
	EOF

	rm -rf $DIR/linux-phicomm-n1*
	rm -rf $DIR/root/.bash_history

}

env_init
gen_rootfs
