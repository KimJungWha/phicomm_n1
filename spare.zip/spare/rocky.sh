#!/bin/bash

DIR="/mnt"
PASSWORD="123"

mirrors() {
	sed -e 's|^mirrorlist=|#mirrorlist=|g' \
	    -e 's|^#baseurl=http://dl.rockylinux.org/$contentdir|baseurl=https://mirrors.aliyun.com/rockylinux|g' \
	    -i.bak \
	    /etc/yum.repos.d/Rocky-*.repo
	
	dnf makecache
	dnf install -y epel-release
}

gen_rootfs() {
	dnf install --installroot $DIR --releasever 8 --setopt=install_weak_deps=False --setopt=tsflags=nodocs -y \
		rootfiles coreutils-single bash tar util-linux-ng dnf \
		iputils iproute traceroute dracut network-scripts NetworkManager \
		vim wget curl epel-release openssh-server openssh-clients openssl systemd-timesyncd \
		NetworkManager-wifi e2fsprogs usbutils
}

clean() {
	rm -rf /mnt/system-root/var/cache/* 
	dnf clean all
	cp /etc/yum.repos.d/* /mnt/system-root/etc/yum.repos.d/ ; \
    rm -rf /var/cache/yum; \
	echo '%_install_langs en_US.UTF-8' > /mnt/system-root/etc/rpm/macros.image-language-conf; \
    echo 'LANG="C.UTF-8"' >  /etc/locale.conf
}

mirrors
gen_rootfs

# dracut -f /boot/initramfs-2.6.32-358.el6.x86_64.img 2.6.32-358.el6.x86_64
